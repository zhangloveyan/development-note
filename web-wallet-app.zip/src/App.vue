<script setup>
import { ref } from 'vue';
import ButtonVue from './components/Button.vue';
import 'vant/es/dialog/style';
import 'vant/es/notify/style';

</script>

<template>
  <ButtonVue></ButtonVue>
</template>

<style lang="less">
body {
  padding: 10px;
}
</style>
