<script setup>
import { ref } from 'vue';
import { showNotify } from 'vant';
import * as bip39 from 'bip39';

const show = ref(false);
const passowrd = ref('');
const mnemonic = ref('');
const showMn = ref(false);
const mnemonicInput = ref('');
const showMnDialog = ref(false);


const createWallet = () => {
    console.log('创建钱包');
    show.value = true;
};

const confirmPassword = () => {
    console.log(passowrd.value);
    if (passowrd.value == '') {
        showNotify({ type: 'danger', message: '请输入密码' });
    } else {
        // mnemonic.value = bip39.generateMnemonic();
        mnemonic.value = 'rival cool scrap settle vocal pole damage high table leave survey faith';
        showMn.value = true;
    }
}

const confirmSave = () => {
    showMn.value = false;
    showMnDialog.value = true;
}

const confirmMnemonic = () => {
    if (mnemonic.value == mnemonicInput.value) {
        console.log('ok');
    }
}

</script>

<template>
    <van-space>
        <van-button type="primary" @click="createWallet">创建钱包</van-button>
        <van-button type="primary">导入钱包</van-button>

        <van-dialog v-model:show="show" title="请输入密码" show-cancel-button @confirm="confirmPassword">
            <van-cell-group inset>
                <van-field v-model="passowrd" label="密码：" placeholder="请输入密码" type="password" />
            </van-cell-group>
        </van-dialog>

        <van-dialog v-model:show="showMnDialog" title="请输入助记词" show-cancel-button @confirm="confirmMnemonic">
            <van-cell-group inset>
                <van-field v-model="mnemonicInput" label="助记词：" placeholder="请输入助记词" />
            </van-cell-group>
        </van-dialog>
    </van-space>
    <template v-if="showMn">
        <p>
            {{ mnemonic }}
        </p>
        <van-button size="mini" @click="confirmSave">
            我已经保存
        </van-button>
    </template>
</template>

<style lang="less">
p {
    user-select: all;
}
</style>
